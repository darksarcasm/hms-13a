package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.dao.IRoomDAO;
import com.cg.hms.dao.RoomDAOImpl;
import com.cg.hms.exception.HMSException;

public class RoomServiceImpl implements IRoomService {
	
private IRoomDAO roomDao;
	
	public RoomServiceImpl() {
		roomDao = new RoomDAOImpl();
	}

	@Override
	public List<Room> listRoom(int hcode,String rtype) throws HMSException {
		return roomDao.listRoom(hcode,rtype);
	}

	@Override
	public List<User> listUserName(int hcode) throws HMSException {
		
		return roomDao.listUserName(hcode);
	}
	
	@Override
	public List<Booking> listBookings(int hcode) throws HMSException {
		
		return roomDao.listBooking(hcode);
	}
}
