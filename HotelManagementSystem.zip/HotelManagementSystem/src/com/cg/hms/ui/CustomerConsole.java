package com.cg.hms.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.AdminServiceImpl;
import com.cg.hms.service.BookingServiceImpl;
import com.cg.hms.service.HotelServiceImpl;
import com.cg.hms.service.IAdminService;
import com.cg.hms.service.IBookingService;
import com.cg.hms.service.IHotelService;
import com.cg.hms.service.IRoomService;
import com.cg.hms.service.IUserService;
import com.cg.hms.service.RoomServiceImpl;
import com.cg.hms.service.UserServiceImpl;

public class CustomerConsole {
	private String currentUser;
	private IHotelService hotelService;
	private IRoomService roomService;
	private IBookingService bookingService;
	private IUserService userService;
	private IAdminService adminService;
	private Scanner scan;
	double perNightCost;
	int userId;

	public CustomerConsole(String currentUser) {
		this.currentUser = currentUser;
	}

	public void start() throws HMSException {
		scan = new Scanner(System.in);
		hotelService = new HotelServiceImpl();
		roomService = new RoomServiceImpl();
		userService = new UserServiceImpl();
		System.out.println("Welcome " + currentUser);
		try {
			Booking book = new Booking();
			userId = userService.getUserId(currentUser);
			book.setUserId(userId);
			System.out.println(book.getUserId());
		} catch (HMSException e1) {
			
			e1.printStackTrace();
		}

		int choice = -1;

		while (choice != 2) {

			System.out.println("[1]Reserve Hotel [2]LogOut");
			System.out.print("Choice> ");
			choice = scan.nextInt();

			switch (choice) {
			case 1:
				reserveHotel();
				break;
			}
		}
	}

	public void reserveHotel() throws HMSException {
		System.out.println("Reserve Hotel");
		List<Hotel> hotels;
		try {
			hotels = hotelService.listHotels();

			if (hotels != null) {
				System.out.println("\tHotel Id\tHotel Name\tCity");
				System.out
						.println("-------------------------------------------");
				for (Hotel hotel : hotels) {
					System.out.println("\t" + hotel.getHotelId() + "\t\t"
							+ hotel.getHotelName() + "\t\t" + hotel.getCity());
				}
			} else {
				System.out.println("No Records Found!");
			}
			
			System.out.print("HotelCode>: ");
			int hcode = scan.nextInt();
			System.out.print("Room Type>:");
			String rtype=scan.next();
			Hotel hotel = hotelService.findHotel(hcode);

			List<Room> rooms = new ArrayList<Room>();
			
			rooms = roomService.listRoom(hcode,rtype);

			if (rooms != null) {
				System.out
						.println("\tHotel Id\tRoom Id\tRoom Type\tPer Night Price\tAvailability");
				System.out
						.println("---------------------------------------------------------------");
				for (Room room : rooms) {
					System.out.println("\t" + room.getHotelId() + "\t\t"
							+ room.getRoomId() + "\t\t" + room.getRoomType()
							+ "\t\t" + room.getPerNightPrice()
							+ "\t\t" + room.getAvailable());
				}
			} else {
				System.out.println("No Records Found!");
			}
			bookingInitials();
		} catch (HMSException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
		} catch (InputMismatchException e){
			throw new HMSException("\nPlease Enter Digits (0-9) only.");
		}
	}

	public void bookingInitials() {

		int diffInDays = 0;
		Booking book = new Booking();
		bookingService = new BookingServiceImpl();
		adminService = new AdminServiceImpl();
		double bookId = Math.random();
		int bookingId = (int) (bookId * 1000);
		book.setBookingId(bookingId);
		Date fDate = null, tDate = null;
		System.out.print("Room Id>: ");
		int rcode;
		rcode = scan.nextInt();
		book.setRoomId(rcode);
		try {
			adminService.modifyRoomAvailability(rcode, "Res");
		} catch (HMSException e2) {
			
			e2.printStackTrace();
		}
		System.out.print("From Date(dd/MM/yyyy):");
		String sFromDate = scan.next();
		try {
			fDate = new SimpleDateFormat("dd/MM/yyyy").parse(sFromDate);
		} catch (ParseException e) {
			System.err.println(e.getMessage());
		}
		System.out.print("To Date(dd/MM/yyyy):");
		String sToDate = scan.next();
		try {
			tDate = new SimpleDateFormat("dd/MM/yyyy").parse(sToDate);
		} catch (ParseException e) {
			System.err.println(e.getMessage());
		}
		if (tDate.compareTo(fDate) > 0) {
			diffInDays = (int) ((tDate.getTime() - fDate.getTime()) / (1000 * 60 * 60 * 24));
			System.out.println("STAY IN DAYS:" + diffInDays);
		} else {
			System.out.println("To date must be > From Date");
		}
		java.sql.Date fromDate = new java.sql.Date(fDate.getTime());
		java.sql.Date toDate = new java.sql.Date(tDate.getTime());
		book.setfDate(fromDate);
		book.settDate(toDate);
		book.setUserId(userId);
		System.out.print("No of Adults:");
		book.setAdults(scan.nextInt());
		System.out.print("No of Children:");
		book.setChild((scan.nextInt()));
		try {
			Room room = bookingService.findAmount(rcode);
			
			perNightCost = room.getPerNightPrice();
		} catch (HMSException e1) {
			// TODO Auto-generated catch block
			System.err.println(e1.getMessage());
		}
		double amount;
		if(book.getAdults()%2==0){ 
			amount = diffInDays*perNightCost*(book.getAdults()/2);//new
		}
		else{
			amount = diffInDays*perNightCost*((book.getAdults()/2)+1);
		}
		book.setAmount(amount);
		try {
			boolean bookTrue = bookingService.saveBooking(book);
			if (bookTrue) {
				System.out.println("Room is Booked for " + currentUser
						+ ".Your amount is " + amount + ".");
			} else {
				System.out.println("Try Again for Room Booking");
			}

		} catch (HMSException e) {
			e.printStackTrace();
		}
	}
}